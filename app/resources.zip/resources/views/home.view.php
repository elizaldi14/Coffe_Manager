<?php
print_r($d);
?>

